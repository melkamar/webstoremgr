(function () {
    window.RECIEVER_TEST_URL = "http://pam-forms-emitter-test.ff.avast.com:8090/api/v2/forms/update/input";
    window.RECIEVER_PRODUCTION_URL = "http://pam-forms-emitter.ff.avast.com:8080/api/v2/forms/update/input";

    window.RECIEVER_TEST_DELETE = "http://pam-forms-emitter-test.ff.avast.com:8090/api/v2/forms/delete/input";
    window.RECIEVER_PRODUCTION_DELETE = "http://pam-forms-emitter.ff.avast.com:8080/api/v2/forms/delete/input";

    window.RECIEVER_TEST_DELETEALL = "http://pam-forms-emitter-test.ff.avast.com:8090/api/v2/forms/delete/page?p=";
    window.RECIEVER_PRODUCTION_DELETEALL = "http://pam-forms-emitter.ff.avast.com:8080/api/v2/forms/delete/page?p=";

    window.EMITTER_TEST_URL = "http://pam-forms-emitter-test.ff.avast.com/api/v2/forms/get/page";
    window.EMITTER_PRODUCTION_URL = "http://pam-forms-emitter.ff.avast.com/api/v2/forms/get/page";
})();
