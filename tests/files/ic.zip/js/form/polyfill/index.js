(function () {
    require("./es5.js");
    require("./typedarray.js");

    require("./wgxpath.install.js");

    if (typeof wgxpath !== 'undefined') {
        wgxpath.install();
    }
})();

