(function () {
    'use strict';

    if (!window.Avast) {
        window.Avast = {};
    }

    window.Avast.sendMessage = function (type, request, callback) {
        chrome.runtime.sendMessage({ type: type, detail: request }, callback);
    };
})();